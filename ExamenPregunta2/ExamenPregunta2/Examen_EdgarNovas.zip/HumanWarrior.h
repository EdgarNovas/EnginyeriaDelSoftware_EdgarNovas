#pragma once
#include "Character.h"
class HumanWarrior
{
public:
	HumanWarrior();
};