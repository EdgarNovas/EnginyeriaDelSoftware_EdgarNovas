#pragma once
namespace DIP
{
	class DIP_Configuration
	{
	public:
		DIP_Configuration() = default;
	};
}