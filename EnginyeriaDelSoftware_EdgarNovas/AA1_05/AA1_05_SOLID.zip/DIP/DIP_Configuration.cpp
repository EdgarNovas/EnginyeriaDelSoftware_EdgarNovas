#include "DIP_Configuration.h"
namespace DIP
{
}