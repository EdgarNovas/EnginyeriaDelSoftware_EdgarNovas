#include "LoadBinaryConfigurationService.h"

void LoadBinaryConfigurationService::LoadConfiguration()
{
    
    // Implementation for loading binary configuration
    std::cout << "Loading configuration from Binary" << std::endl;
    
}
