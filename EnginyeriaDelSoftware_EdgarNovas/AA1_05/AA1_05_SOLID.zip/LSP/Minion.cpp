#include "Minion.h"

namespace LSP {
	Minion::Minion()
	{
	}
	int Minion::GetHealth()
	{
		return health;
	}
}