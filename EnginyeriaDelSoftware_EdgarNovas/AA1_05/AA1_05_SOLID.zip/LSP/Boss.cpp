#include "Boss.h"

namespace LSP {
	Boss::Boss()
	{
	}
	int Boss::GetHealth()
	{
		return health;
	}
}