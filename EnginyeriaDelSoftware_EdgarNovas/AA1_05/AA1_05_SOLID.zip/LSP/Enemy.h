#pragma once
namespace LSP {
	class LSP_Enemy
	{
	public:
		LSP_Enemy() = default;
		virtual ~LSP_Enemy() = default;
		virtual int GetHealth() = 0;
	};
}