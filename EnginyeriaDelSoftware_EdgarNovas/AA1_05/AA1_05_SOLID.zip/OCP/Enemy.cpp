#include "Enemy.h"

namespace OCP {
	Enemy::Enemy(int attackDamage, int hp) : attackDamage(attackDamage), hp(hp)
	{
	}


}