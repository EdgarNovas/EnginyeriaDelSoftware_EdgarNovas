#pragma once
namespace SRP
{
	class SRPMain
	{
	public:
		void Main();
	};
}