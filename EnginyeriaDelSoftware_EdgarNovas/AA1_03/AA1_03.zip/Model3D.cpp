#include "Model3D.h"

void Model3D::Draw()
{
	float x = 5.3f;
	float y = 2.5f;
	float z = 7.4f;

	std::cout << "The 3D Model I drew is at " << x << " " << y << " " << z << std::endl;
	
}
