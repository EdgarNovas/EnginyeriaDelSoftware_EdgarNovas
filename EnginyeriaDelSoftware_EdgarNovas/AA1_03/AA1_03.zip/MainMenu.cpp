#include "MainMenu.h"

void MainMenu::Draw(){
	std::cout << "Imatge joc" << std::endl;
	std::cout << "Boto clicable per comen�ar el joc" << std::endl;
	std::cout << "Boto clicable per mostrar les millors puntuacions" << std::endl;
	std::cout << "Boto clicable per tancar el joc" << std::endl;
}