#pragma once
#include <string>
#include <iostream>
class Renderer
{
public:
	virtual void Draw() = 0;
};

