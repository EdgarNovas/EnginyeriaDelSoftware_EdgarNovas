#pragma once
#include "Menu.h"
class MainMenu: public Menu {
private:

public:
	MainMenu() {

	}


	void Draw() override;

};