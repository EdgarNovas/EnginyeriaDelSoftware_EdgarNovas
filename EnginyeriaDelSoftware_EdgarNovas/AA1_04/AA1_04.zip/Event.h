#pragma once


class Event
{
public:
	int key;
	Event(int key)
		: key(key) {}
};


